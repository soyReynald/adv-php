<!DOCTYPE html>
<html>
<head>
	<title>Casteando (casting) variables</title>
</head>
<body>
	<?php

	$precio = "19.95 pesos";
	$cargo = 16.25;

	$lista = array("nombre"=>"Rasmus", "apellido"=>"Lerdorf", "ocupacion"=>"Programador", "nacionalidad"=>"Groenlandés", "nacimiento"=>"1968-11-22");

	?>

</body>
</html>