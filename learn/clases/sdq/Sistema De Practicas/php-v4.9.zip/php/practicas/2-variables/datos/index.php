<!DOCTYPE html>
<html>
<head>
	<title>Tipos de datos</title>
</head>
<body>
	<?php

	#$intitucion = "SDQ Training Center";

	//$activo = true;

	//$precio = 15.36;
	/*
	$cantidad = 42;

	$cursos = ["PHP & MySQL", "HTML 5 & CSS 3", "jQuery", "Java"];
	*/
	#$data = null;

	?>
</body>
</html>