<?php

	$precio = 15.36;

	$cantidad = 20;

	$cursos = ["MySQL", "PHP", "AutoCAD", "Fotografía", "Photoshop"];

	$activo = false;

	$empleado = array("nombre"=>"Rasmus", "apellido"=>"Lerdorf", "ocupacion"=>"Programador", "nacionalidad"=>"Groenlandés", "nacimiento"=>"1968-11-22");

?>
<!DOCTYPE html>
<html>
<head>
	<title>Mostrando información de las variables</title>
</head>
<body>

	<?php

	// Código aquí

	?>

</body>
</html>