<!DOCTYPE html>
<html>
<head>
	<title>Declarando variables</title>
</head>
<body>

</body>
</html>