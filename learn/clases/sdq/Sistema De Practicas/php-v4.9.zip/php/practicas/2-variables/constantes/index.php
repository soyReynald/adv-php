<!DOCTYPE html>
<html>
<head>
	<title>Constantes</title>
</head>
<body>
	<?php

		#Creación de una constante
		define('SDQ', 'SDQ Training Center');

		echo SDQ;

	?>
</body>
</html>