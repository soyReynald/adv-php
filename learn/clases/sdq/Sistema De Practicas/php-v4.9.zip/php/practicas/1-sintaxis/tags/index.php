<!DOCTYPE html>
<html>
<head>
	<title>Mi primera página en PHP</title>
</head>
<body>
	<?php echo '#dfd'; ?>
	<br>
	<?php echo '#f00'; ?>
</body>
</html>