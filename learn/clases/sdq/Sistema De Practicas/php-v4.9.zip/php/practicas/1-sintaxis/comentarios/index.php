<!DOCTYPE html>
<html>
<head>
	<title>Comentarios en PHP</title>
</head>
<body>
	<?php

	$data = 'SDQ Training Center';
	$fecha = Date('d-m-Y');

	echo $data . ' - ' . $fecha;

	?>
	<hr>
	<?php

	//$lista = array('PHP', 'MySQL', 'Programación', 'HTML', 'CSS', 'Base de datos');

	/*
	foreach($lista as $elemento){

		echo $elemento . '<br>';

	}
	*/
	
	?>
</body>
</html>