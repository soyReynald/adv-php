<!DOCTYPE html>
<html>
<head>
	<title>Punto y coma son obligatorios en PHP</title>
</head>
<body>
	<?php

	$lista = array('PHP', 'MySQL', 'Programación', 'HTML', 'CSS', 'Base de datos');

	foreach($lista as $elemento){

		echo $elemento . '<br>'

	}

	?>
</body>
</html>