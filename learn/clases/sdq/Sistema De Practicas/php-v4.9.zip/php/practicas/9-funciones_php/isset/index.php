<?php

$data = 15;

$cursos = ["PHP", "jQuery", "InDesign", "Audio", "HTML", "Laravel"];

?>
<!DOCTYPE html>
<html>
<head>
	<title>Funciones isset y unset</title>
</head>
<body>
	<?php
	# Código aquí
	?>
</body>
</html>