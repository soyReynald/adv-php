<!DOCTYPE html>
<html>
<head>
	<title>Funciones de correo</title>
</head>
<body>
	<?php

	?>
</body>
</html>