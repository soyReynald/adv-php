<?php

	# Parte A
	define('_ALERTA_', 'Tiene X mensajes de los cuales Y no han sido leidos. Z es la persona que le ha enviado más mensajes.');
	$mensajes = 45;
	$noLeidos = 15;
	$persona = 'Juan Luis Guerra';

	# Parte B
	$division = 'El resultado de dividir X entre Y es Z?';
	$x = 10;
	$y = 3;

?>
<!DOCTYPE html>
<html>
<head>
	<title>Función print format</title>
</head>
<body>
	<?php

	// Su código aquí

	?>
</body>
</html>