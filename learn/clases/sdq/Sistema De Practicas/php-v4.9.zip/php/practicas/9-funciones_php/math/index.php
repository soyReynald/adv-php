<?php

	$medida = -34;

	$numero = 52.369;
	$precio = 84.52;
	$cargo = 44.69;

	$minimo = 5;
	$maximo = 9;

?>
<!DOCTYPE html>
<html>
<head>
	<title>Funciones matemáticas</title>
</head>
<body>
	<?php

	?>
</body>
</html>