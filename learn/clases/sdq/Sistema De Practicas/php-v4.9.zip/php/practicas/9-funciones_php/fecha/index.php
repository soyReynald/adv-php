<?php
	$cadena = '2009-05-10 14:32:10';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Funciones de Fecha</title>
</head>
<body>
	<?php
	# Su código aquí
	?>
</body>
</html>