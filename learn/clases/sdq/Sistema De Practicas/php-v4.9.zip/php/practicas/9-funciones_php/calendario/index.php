<!DOCTYPE html>
<html>
<head>
	<title>Calendario en PHP</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css">
</head>
<body>
	<div class="container">
		<table class="table">
			<tr>
				<th colspan="7" class="text-center">Mes y año</th>
			</tr>
			<tr>
				<th class="text-danger">Domingo</th>
				<th>Lunes</th>
				<th>Martes</th>
				<th>Miércoles</th>
				<th>Jueves</th>
				<th>Viernes</th>
				<th class="text-danger">Sábado</th>
			</tr>
			<?php

			?>
		</table>
	</div>
	
</body>
</html>