<?php
# Código aquí
?>
<!DOCTYPE html>
<html>
<head>
	<title>Función header</title>
</head>
<body>
<p>Si ejecutamos la función header después de una salida de echo, print o incluso una línea vacía, esta nos dará un mensaje de advertencia diciendo que cabeceras anteriores a ella han sido enviadas.</p>
</body>
</html>