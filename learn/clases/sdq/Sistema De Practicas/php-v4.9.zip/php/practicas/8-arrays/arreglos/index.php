<!DOCTYPE html>
<html>
<head>
	<title>Funciones de los arreglos (arrays)</title>
</head>
<body>
	<?php

	$cursos = ["AutoCAD", "Photoshop", "Illustrator", "InDesign", "Revit"];

	?>
</body>
</html>