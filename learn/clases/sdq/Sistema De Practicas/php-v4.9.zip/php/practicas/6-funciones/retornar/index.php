<?php

	// Crear las funciones aquí

?>
<!DOCTYPE html>
<html>
<head>
	<title>Retornando valores de las funciones</title>
</head>
<body>

	<?php

	// Llamar las funciones aquí

	?>

</body>
</html>