<!DOCTYPE html>
<html>
<head>
	<title>Función que dibuja cuadrado de asteriscos</title>
</head>
<body>
	<?php

	/* 	Ejemplo de resultado

		* * * * * * * * * *
		* * * * * * * * * *
		* * * * * * * * * *
		* * * * * * * * * *
		* * * * * * * * * *
		* * * * * * * * * *
		* * * * * * * * * *
		* * * * * * * * * *
		* * * * * * * * * *
		* * * * * * * * * *
	
	*/

	?>
</body>
</html>