<!DOCTYPE html>
<html>
<head>
	<title>Iteraciones (loop) WHILE</title>
</head>
<body>
	<?php

	$cursos = ["PHP & MySQL", "HTML5 y CSS3", "nodeJS", "Laravel", "jQuery", "SQL"];

	?>
</body>
</html>