<?php

$empleados = array(
				array("nombre"=>"Raúl", "apellido"=>"Molina"),
				array("nombre"=>"Víctor", "apellido"=>"Gómez"),
				array("nombre"=>"Amelia", "apellido"=>"Vega"),
				array("nombre"=>"Alicia", "apellido"=>"Ortega"),
				);

?>
<!DOCTYPE html>
<html>
<head>
	<title>Iteraciones (loop) FOREACH</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css">
</head>
<body>
	<div style="margin-top: 20px" class="container">
		<table class="table table-striped">
			<tr>
				<th>Nombre</th>
				<th>Apellido</th>
			</tr>
			<?php

			#Código aquí

			?>
		</table>
	</div>
</body>
</html>