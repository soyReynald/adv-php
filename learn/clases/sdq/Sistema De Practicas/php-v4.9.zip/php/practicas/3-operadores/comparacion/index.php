<!DOCTYPE html>
<html>
<head>
	<title>Operadores de comparación</title>
</head>
<body>
	<?php

	$a = 2;
	$b = 3;
	$c = 4;

	$x = 5;
	$y = 6;
	$z = 7;

	/* Código comentado

	if(condición A){
		echo 'La variable a es menor que la variable x';
	} else {
		echo 'La variable a NO es menor que la variable x';
	}

	if(condición B){
		echo 'La variable z es diferente que la variable y';
	} else {
		echo 'La variable z NO es diferente que la variable y';
	}

	if(condición C){
		echo 'La variable c es mayor o igual que la variable b';
	} else {
		echo 'La variable c NO es mayor ni igual que la variable b';
	}

	if(condición D){
		echo 'La variable b es identica que la variable z';
	} else {
		echo 'La variable z NO es identica que la variable z';
	}

	*/

	?>
</body>
</html>