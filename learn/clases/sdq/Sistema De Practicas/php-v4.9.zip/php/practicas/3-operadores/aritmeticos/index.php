<!DOCTYPE html>
<html>
<head>
	<title>Operadores aritméticos</title>
</head>
<body>
<?php

	$a = 2;
	$b = 3;
	$c = 4;

	$x = 5;
	$y = 6;
	$z = 7;

?>
</body>
</html>