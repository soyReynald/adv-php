<!DOCTYPE html>
<html>
<head>
	<title>Operadores de arreglos (arrays)</title>
</head>
<body>
	<?php

		$lista = ['MySQL', 'PHP', 'HTML'];
		$cursos = array("CSS", "Web", "MySQL");

		$empresa = [
					'nombre'=>'SDQ Training Center',
					'web'=>'www.sdq.com.do',
					];

		$datosEmpresa = array("correo"=>'info@sdq.com.do', 'telefono'=>'809-333-7610');

		$completo = array("MySQL", "PHP", "HTML", "CSS", "Web", "MySQL");

		/* Código comentado
		if(condición){

			echo 'Los arrays son identicos';

		} else {

			echo 'Los arrays NO son identicos';

		}
		*/

	?>
</body>
</html>