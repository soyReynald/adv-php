<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>MySQL desde PHP</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css">
</head>
<body>

</body>
</html>