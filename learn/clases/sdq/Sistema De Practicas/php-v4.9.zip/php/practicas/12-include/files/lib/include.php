<?php

$funciones = ['isset', 'unset', 'file_exists', 'get_file_contents', 'in_array', 'is_array'];

$nombre = "PHP & MySQL";

$cantidad = 15.69;

?>