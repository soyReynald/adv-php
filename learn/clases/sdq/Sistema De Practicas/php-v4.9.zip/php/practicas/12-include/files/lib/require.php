<?php

return '{
			"nombre"	:	"SDQ Training Center",
			"cursos"	:	[
								"PHP & MySQL",
								"AutoCAD",
								"Revit",
								"HTML 5 & CSS 3",
								"Java"
							],
			"fecha"		:	"2009-05-10"
		}';

?>