<?php
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Include y require en PHP</title>
</head>
<body>

</body>
</html>