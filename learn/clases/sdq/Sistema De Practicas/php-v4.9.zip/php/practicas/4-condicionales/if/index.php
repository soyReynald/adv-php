<!DOCTYPE html>
<html>
<head>
	<title>Condicional IF</title>
</head>
<body>
	<?php

	$heroe = array('nombre'=>'Bruno', 'apellido'=>'Díaz', 'codename'=>'Batman');

	$temp = array();
	$temp['nombre'] = "Bruno";
	$temp['apellido'] = "Díaz";
	$temp['codename'] = "Bat-man";

	$x = 35;

	$y = '35';

	#comprobar e imprimir un mensaje si el array $heroe y el array $temp son identicos

	#comprobar e imprimir un mensaje si la variable $x es diferente de la variable $y

	?>
</body>
</html>