<!DOCTYPE html>
<html>
<head>
	<title>Condicionales IF, ELSEIF y ELSE</title>
</head>
<body>
	<?php

	$a = 4;
	$b = 6;
	$c = 3;

	// Código aquí

	?>
</body>
</html>