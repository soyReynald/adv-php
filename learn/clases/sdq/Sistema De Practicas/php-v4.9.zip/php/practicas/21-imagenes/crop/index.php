<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Recortando imagenes en PHP</title>
</head>
<body>

</body>
</html>