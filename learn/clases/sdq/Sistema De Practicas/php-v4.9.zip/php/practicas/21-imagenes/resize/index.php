<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Cambiando el tamaño de imagenes en PHP</title>
</head>
<body>

</body>
</html>