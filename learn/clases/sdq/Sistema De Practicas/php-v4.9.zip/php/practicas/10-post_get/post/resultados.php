<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Resultados variable $_POST</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css">
</head>
<body>
	<div style="margin-top: 20px" class="container">
		<table class="table table-striped">
			<tr>
				<td>Nombre:</td>
				<td>{ nombre aquí }</td>
			</tr>
			<tr>
				<td>País:</td>
				<td>{ país aquí }</td>
			</tr>
			<tr>
				<td>Sexo:</td>
				<td>{ sexo aquí }</td>
			</tr>
			<tr>
				<td>Intereses:</td>
				<td>{ intereses aquí }</td>
			</tr>
			<tr>
				<td>Comentario:</td>
				<td>{ comentario aquí }</td>
			</tr>
		</table>
	</div>
</body>
</html>