<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Cookies en PHP</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css">
</head>
<body>

</body>
</html>