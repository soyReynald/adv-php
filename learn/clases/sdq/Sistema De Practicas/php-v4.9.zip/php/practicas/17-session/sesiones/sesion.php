<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Variable de sesión</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css">
</head>
<body>

</body>
</html>