<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Cookies en PHP</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css">
</head>
<body>
	<div style="margin-top: 20px" class="container">
		<form>
		  	<div class="form-group">
		    	<label for="nombre">Nombre</label>
		    	<input type="text" class="form-control" id="nombre" placeholder="Coloque su nombre">
		  </div>
		  <div class="form-group">
		    	<label for="correo">Correo</label>
		    	<input type="email" class="form-control" id="correo" placeholder="Coloque su correo">
		  </div>
		  <button type="submit" class="btn btn-primary">Guardar</button>
		</form>	
	</div>
	
</body>
</html>