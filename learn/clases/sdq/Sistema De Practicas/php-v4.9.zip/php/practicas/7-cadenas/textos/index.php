<!DOCTYPE html>
<html>
<head>
	<title>Cadenas de texto</title>
</head>
<body>
	<?php

	$nombre = "SDQ Training Center";
	$cursos = "PHP, MySQL, HTML, jQuery, CSS, Java, Laravel";

	$html = '<ul><li>PHP</li><li>MySQL</li><li>jQuery</li><li>Java</li></ul>';

	/* Ejemplo de impresión vertical
	
		S
		D
		Q

	*/

	?>
</body>
</html>