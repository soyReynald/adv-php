<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Suma en javascript</title>
</head>
<body>
	<script>
	var n1 = parseInt(prompt("Ingrese un numero a sumar:"));
	var n2 = parseInt(prompt("Ingrese el segundo numero a sumar:"));

	var res = "El resultado es: "+ (n1 + n2);
	alert(res);
	</script>

</body>
</html>