<?php

define('_USERNAME_', 'Username');
define('_PASSWORD_', 'Password');
define('_LOGIN_', 'Login');
define('_CREATE_ACCOUNT_', 'Create Account');

?>