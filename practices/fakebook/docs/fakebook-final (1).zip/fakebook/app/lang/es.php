<?php

define('_USERNAME_', 'Usuario');
define('_PASSWORD_', 'Contraseña');
define('_LOGIN_', 'Entrar');
define('_CREATE_ACCOUNT_', 'Crear Cuenta');

?>