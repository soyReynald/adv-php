    
        <footer>
            <small>Fakebook &copy</small>
        </footer>
    </div>  
</body>
</html>