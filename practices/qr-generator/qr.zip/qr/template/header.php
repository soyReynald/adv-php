<div class="bg-primary position-relative">
  <div class="overlay-gradient"></div>
  <div class="container position-relative">
  	<div class="row py-5">
    	<div class="col">
        <h1 class="display-1">Generador QR Avanzado</h1>
        <p>Abajo aparecen una gran cantidad de opciones super sencillas he intuitivas</p>
        <p><a href="#" class="btn btn-primary btn-lg shadow" role="button">Más información &raquo;</a></p>
    </div>
    </div>
  </div>
</div>